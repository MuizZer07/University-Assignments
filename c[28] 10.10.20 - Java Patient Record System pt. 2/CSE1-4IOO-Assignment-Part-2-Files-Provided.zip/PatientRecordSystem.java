import java.io.*;
import java.util.*;

public class PatientRecordSystem
{
	// collection of observation types and patients
	private ObservationType [] observationTypes;
	private int observationTypeCount;

	private Patient [] patients;
	private int patientCount;

	public PatientRecordSystem()
	{
		observationTypes = new ObservationType[50];
		patients = new Patient[50];
		observationTypeCount = 0;
		patientCount = 0;
	}

	public String toString()
	{
		// return details of the observation types
		String str = "===== PATIENT RECORD SYSTEM =====\n";
		str = str + "OBSERVATION TYPES:\n";

		for(int i = 0; i < observationTypeCount; i++)
		{
			str = str + ">> " + observationTypes[i]+ "\n" ;
		}

		// and details of the patients
		str = str + "\nPATIENTS:\n";
		for(int i = 0; i < patientCount; i++)
		{
			str = str + ">> " + patients[i] + "\n" ;
		}

		return str;
	}

	// Method to add measurement observation types
	public void addMeasurementObservationType(String code, String name, String unit)
	throws Exception
	{
		int index = searchObservationType(code);
		boolean pre = (index == -1);
		if (! pre )
		{
			throw new Exception("ERROR: The measurement observation type already exists");
		}

		observationTypes[observationTypeCount++] =
			new MeasurementObservationType(code, name, unit);
	}

	// Helper method: Search for an observation type
	// Return index if found
	// Return -1 if not
	public int searchObservationType(String code)
	{
		for(int i = 0; i < observationTypeCount; i++)
		{
			if( observationTypes[i].getCode().equals(code))
			{
				return i;
			}
		}
		return -1;
	}

	// Add category observation types
	public void addCategoryObservationType(String code, String name, String [] categories)
	throws Exception
	{
		int index = searchObservationType(code);
		boolean pre = (index == -1);
		if (! pre )
		{
			throw new Exception("ERROR: The category observation type already exists");
		}

		observationTypes[observationTypeCount++]
			= new CategoryObservationType(code, name, categories);
	}

	// Add a new patient
	public void addPatient(String id, String name) throws Exception
	{
		int index = searchPatient(id);
		boolean pre = (index == -1);
		if (! pre )
		{
			throw new Exception("ERROR: The patient already exists");
		}

		patients[patientCount++] = new Patient(id, name);
	}

	// Search for a patient by patient id
	// return index if the patient is found
	// Return -1 if the patient is not found
	public int searchPatient(String id)
	{
		for(int i = 0; i < patientCount; i++)
		{
			if( patients[i].getId().equals(id))
			{
				return i;
			}
		}
		return -1;
	}

	// Add a measurement observation for a patient
	public void addMeasurementObservation(String id, String code, double value)
	throws Exception
	{
		int patientIndex = searchPatient(id);
		boolean pre1 = (patientIndex != -1);
		if (! pre1 )
		{
			throw new Exception("ERROR: The patient does not exist");
		}

		int observationTypeIndex = searchObservationType(code);
		boolean pre2 = (observationTypeIndex != -1);
		if (! pre2 )
		{
			throw new Exception("ERROR: The measurement observation type does not exist");
		}

		// pre3 = 'patient does not have observation of this type'
		// We can try to test it here
		// But we can leave the checking to the addObservation method

		patients[patientIndex++].addObservation(
			new MeasurementObservation(
				(MeasurementObservationType) observationTypes[observationTypeIndex], value));
	}

	// method to add a category observation for a patient
	public void addCategoryObservation(String id, String code, String value)
	throws Exception
	{
		int patientIndex = searchPatient(id);
		boolean pre1 = (patientIndex != -1);
		if (! pre1 )
		{
			throw new Exception("ERROR: The patient does not exist");
		}

		int observationTypeIndex = searchObservationType(code);
		boolean pre2 = (observationTypeIndex != -1);
		if (! pre2 )
		{
			throw new Exception("ERROR: The category observation type does not exist");
		}

		// pre3 = 'patient does not have observation of this type
		// pre4 = 'category value must be one of those of the category observation type'
		// We leave the first check to the constructor of CategoryObservation
		// and the second check to addObservation method

		Patient patient = patients[patientIndex];
		ObservationType observationType = observationTypes[observationTypeIndex];

		patient.addObservation(
			new CategoryObservation((CategoryObservationType) observationType, value));
	}

	// retrieve details of an observation type
	public String retrieveObservationTypeDetails(String code)
	{
		int index = searchObservationType(code);

		if (index == -1)
		{
			return "There is no such observation type";
		}
		else
		{
			return observationTypes[index].toString();
		}
	}

	// retrieve details of a patient
	public String retrievePatientDetails(String id)
	{
		int index = searchPatient(id);

		if (index == -1)
		{
			return "There is no such patient";
		}
		else
		{
			return patients[index].toString();
		}
	}

	public void saveData() throws Exception
	{
		//complete the method to write the data in five
		//text files
		
		//if you want, you can delegate tasks of writing each 
		//text file to individual methods. That way, the code is 
		//easier to manage. It is just a suggestion.
		//you can implement the method in any way you see fit. 
	}

	public void loadData() throws Exception 
	{
		//clear existing data first:
		observationTypes = new ObservationType[50];
		patients = new Patient[50];
		observationTypeCount = 0;
		patientCount = 0;

		//now, complete the method to load data from five
		//text files
	}


}